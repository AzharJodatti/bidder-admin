package com.invictusdynamics.bookie.controller;

import java.util.ResourceBundle;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.invictusdynamics.bookie.utility.Constants;

/**
 * 
 * @author Amol K Golhar
 * @since 12 April 2018
 *
 */
@Controller
public class AdminController {

/*	*//** Resource bundle for exception message *//*
	ResourceBundle messageBundle = ResourceBundle.getBundle(Constants.MESSAGE_BUNDLE_NAME);

	@RequestMapping(value = "/adminPannel", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView adminPannel() {
		return new ModelAndView("admin/AdminHome");
	}*/
	
}
