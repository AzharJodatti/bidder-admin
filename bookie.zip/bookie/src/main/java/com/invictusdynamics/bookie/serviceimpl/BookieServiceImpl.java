package com.invictusdynamics.bookie.serviceimpl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.ResourceBundle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.invictusdynamics.bookie.entity.BookieDetails;
import com.invictusdynamics.bookie.sequence.BookieSequence;
import com.invictusdynamics.bookie.service.BookieService;
import com.invictusdynamics.bookie.service.SequenceDao;
import com.invictusdynamics.bookie.utility.Constants;

@Service("bookieServiceImpl")
public class BookieServiceImpl implements BookieService {

	/** Resource bundle for message */
	ResourceBundle messageBundle = ResourceBundle.getBundle(Constants.MESSAGE_BUNDLE_NAME);

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private SequenceDao sequenceDao;

	@Override
	public String saveBookieDetails(String bookieName, long coinTransferValue, long commission) {
		String returnValue = messageBundle.getString("saveBookieFailure");
		if (bookieName != null && bookieName != "") {
			try {
				BookieDetails bookieDetails = new BookieDetails();
				bookieDetails.setId(sequenceDao.getNextSequenceId(Constants.BOOKIE_SEQ_KEY, BookieSequence.class));
				bookieDetails.setBookieName(bookieName);
				bookieDetails.setCoinTransferValue(coinTransferValue);
				bookieDetails.setCommission(commission);
				
				/** TODO start:This value should be set from session. */
				bookieDetails.setCoinTransferFrom("Admin");
				bookieDetails.setCreatedBy("Admin");
				bookieDetails.setUpdatedBy("Admin");
				/** TODO end :This value should be set from session. */

				bookieDetails.setCreatedAt(new Timestamp(new Date().getTime()));
				bookieDetails.setUpdatedAt(new Timestamp(new Date().getTime()));

				mongoTemplate.save(bookieDetails);
				returnValue = messageBundle.getString("saveBookieSuccess");
			} catch (Exception exception) {
				returnValue = messageBundle.getString("saveBookieFailure");
				throw exception;
			}
		}
		return returnValue;
	}

}
