package com.invictusdynamics.bookie.service;

public interface CoinService {
	public String saveCoins(Long coinsValue);
}
