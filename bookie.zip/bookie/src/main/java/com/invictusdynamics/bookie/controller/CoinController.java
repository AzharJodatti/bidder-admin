package com.invictusdynamics.bookie.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.invictusdynamics.bookie.entity.Recharges;
import com.invictusdynamics.bookie.sequence.CoinSequence;
import com.invictusdynamics.bookie.service.SequenceDao;
import com.invictusdynamics.bookie.utility.Constants;

/**
 * @author Amol K Golhar
 * @since 19 April 2018
 *
 */
@Controller
public class CoinController {

	/** Resource bundle for exception message */
	ResourceBundle messageBundle = ResourceBundle.getBundle(Constants.MESSAGE_BUNDLE_NAME);

	final static Logger logger = Logger.getLogger(CoinController.class);

	@Autowired
	private SequenceDao sequenceDao;

	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	@Qualifier("")
	
	/** Resource bundle for exception message */
	@RequestMapping(value = "/coins", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView coinsPage() {
		return new ModelAndView("coin/Coin");
	}
	
	@RequestMapping(value = "/saveCoin", method = RequestMethod.POST)
	@ResponseBody
	public String saveCoin(@RequestParam("coinValue") long coinValue) {
		String returnMessage = messageBundle.getString("coinSaveFailureMsg");
		try {
			
			
			/*Recharges recharges = new Recharges();

			recharges.setId(sequenceDao.getNextSequenceId(Constants.COIN_SEQ_KEY, CoinSequence.class));
			recharges.setCoins(coinValue);
			recharges.setRecharedBy("Amol");
			recharges.setRechargeDate(new Timestamp(new Date().getTime()));
			
			*//** "GENERATED | TRANSFERED" *//*
			recharges.setType("GENERATED");
			
			*//**TODO : Read from session*//*
			recharges.setCreatedBy("Amol");
			recharges.setUpdatedBy("Amol"); 
			recharges.setCreatedAt(new Timestamp(new Date().getTime()));
			recharges.setUpdatedAt(new Timestamp(new Date().getTime()));

			mongoTemplate.save(recharges);

			returnMessage = messageBundle.getString("coinSaveSuccessMsg");*/
		} catch (Exception exception) {
			throw exception;
		}
		return returnMessage;
	}
}
