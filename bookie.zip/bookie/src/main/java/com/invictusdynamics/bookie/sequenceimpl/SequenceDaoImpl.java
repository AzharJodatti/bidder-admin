package com.invictusdynamics.bookie.sequenceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.invictusdynamics.bookie.exception.SequenceException;
import com.invictusdynamics.bookie.sequence.BookieSequence;
import com.invictusdynamics.bookie.sequence.CoinSequence;
import com.invictusdynamics.bookie.sequence.LuckyNumberSequence;
import com.invictusdynamics.bookie.sequence.SequenceCounter;
import com.invictusdynamics.bookie.service.SequenceDao;

public class SequenceDaoImpl implements SequenceDao {

	@Autowired
	private MongoTemplate mongoTemplate;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public long getNextSequenceId(String key, Class className) {
		Query query = new Query(Criteria.where("_id").is(key));
		Integer sequenceNumber = null;

		/* Update object increase sequence id by 1 */
		Update update = new Update();

		/* return new increased id */
		FindAndModifyOptions options = new FindAndModifyOptions();
		options.returnNew(true);

		if (className != null && className.getName().equals("com.invictusdynamics.bookie.sequence.CoinSequence")) {
			update.inc("coinSeq", 1);
			CoinSequence coinSequence = (CoinSequence) mongoTemplate.findAndModify(query, update, options, className);
			sequenceNumber = coinSequence.getCoinSeq();
		} else if (className != null && className.getName().equals("com.invictusdynamics.bookie.sequence.SequenceCounter")) {
			update.inc("seq", 1);
			SequenceCounter sequenceCounter = (SequenceCounter) mongoTemplate.findAndModify(query, update, options, className);
			sequenceNumber = sequenceCounter.getSeq();
		} else if (className != null && className.getName().equals("com.invictusdynamics.bookie.sequence.LuckyNumberSequence")) {
			update.inc("luckyNumSeq", 1);
			LuckyNumberSequence luckyNumberSequence = (LuckyNumberSequence) mongoTemplate.findAndModify(query, update, options, className);
			sequenceNumber = luckyNumberSequence.getLuckyNumSeq();
		} else if (className != null && className.getName().equals("com.invictusdynamics.bookie.sequence.BookieSequence")) {
			update.inc("bookieSequence", 1);
			BookieSequence bookieSequence = (BookieSequence) mongoTemplate.findAndModify(query, update, options, className);
			sequenceNumber = bookieSequence.getBookieSequence();
		}

		/* if no id, throws SequenceException optional, just a way to tell user when the sequence id is failed to generate. */
		if (sequenceNumber == null) {
			throw new SequenceException("Unable to get sequence id for key : " + key);
		}
		return sequenceNumber;
	}

}
