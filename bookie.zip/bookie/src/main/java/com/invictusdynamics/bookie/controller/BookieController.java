package com.invictusdynamics.bookie.controller;

import java.util.ResourceBundle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.invictusdynamics.bookie.service.BookieService;
import com.invictusdynamics.bookie.utility.Constants;


@Controller
public class BookieController {

	/** Resource bundle for exception message */
	ResourceBundle messageBundle = ResourceBundle.getBundle(Constants.MESSAGE_BUNDLE_NAME);

	@Autowired
	@Qualifier("bookieServiceImpl")
	private BookieService bookieService; 
	
	@RequestMapping(value = "/bookieHome", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView bookieHome() {
		return new ModelAndView("bookie/BookieHome");
	}
	
	@RequestMapping(value = "/saveBookie", method = RequestMethod.POST)
	@ResponseBody
	public String saveBookie(@RequestParam("bookieName") String bookieName, @RequestParam("coinTransferValue") long coinTransferValue, @RequestParam("commission") long commission) {
		String returnValue = "";
		try {
			returnValue = bookieService.saveBookieDetails(bookieName, coinTransferValue, commission);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return returnValue;
	}
	
	
}
