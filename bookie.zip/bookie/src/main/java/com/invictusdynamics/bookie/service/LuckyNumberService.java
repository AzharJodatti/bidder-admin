package com.invictusdynamics.bookie.service;

public interface LuckyNumberService {
	
	public String saveLuckyNumber(Long openValue, Long closeValue, String region);
}
