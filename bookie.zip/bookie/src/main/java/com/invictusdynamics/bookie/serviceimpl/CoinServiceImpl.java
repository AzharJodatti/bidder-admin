package com.invictusdynamics.bookie.serviceimpl;

import org.springframework.stereotype.Service;

import com.invictusdynamics.bookie.service.CoinService;

@Service("coinServiceImpl")
public class CoinServiceImpl implements CoinService {

	@Override
	public String saveCoins(Long coinsValue) {
		return null;
	}

}
