package com.invictusdynamics.bookie.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "bookie_details")
public class BookieDetails {

	@Id
	private Long id;
	private String bookieName;
	private Long coinTransferValue;
	private Long commission;
	private String coinTransferFrom;

	private String createdBy;
	private String updatedBy;
	private Date createdAt;
	private Date updatedAt;

	public BookieDetails() {
		super();
	}

	public BookieDetails(long id, String bookieName, long coinTransferValue, long commission, String coinTransferFrom, String createdBy, String updatedBy, Date createdAt, Date updatedAt) {
		super();
		this.id = id;
		this.bookieName = bookieName;
		this.coinTransferValue = coinTransferValue;
		this.commission = commission;
		this.coinTransferFrom = coinTransferFrom;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBookieName() {
		return bookieName;
	}

	public void setBookieName(String bookieName) {
		this.bookieName = bookieName;
	}

	public long getCoinTransferValue() {
		return coinTransferValue;
	}

	public void setCoinTransferValue(long coinTransferValue) {
		this.coinTransferValue = coinTransferValue;
	}

	public long getCommission() {
		return commission;
	}

	public void setCommission(long commission) {
		this.commission = commission;
	}

	public String getCoinTransferFrom() {
		return coinTransferFrom;
	}

	public void setCoinTransferFrom(String coinTransferFrom) {
		this.coinTransferFrom = coinTransferFrom;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String toString() {
		return "BookieDetails [id=" + id + ", bookieName=" + bookieName + ", coinTransferValue=" + coinTransferValue + ", commission=" + commission + ", coinTransferFrom=" + coinTransferFrom + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + "]";
	}

}
