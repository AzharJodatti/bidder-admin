package com.invictusdynamics.bookie.utility;

/**
 * This class contains constants used across the application
 * 
 * @author Amol K Golhar
 * @since 12 April 2018
 * 
 */
public class Constants {

	public static final String RESOURCE_BUNDLE_NAME = "resource";
	public static final String MESSAGE_BUNDLE_NAME = "messages";

	public static final int REGISTER_FLAG = 1;

	public static final String YES_FLAG = "Y";
	public static final String NO_FLAG = "N";

	public static final String YES_VALUE = "Yes";
	public static final String NO_VALUE = "No";

	public static final String EMPTY_VALUE = "";

	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	public static final String NAN = "NaN";
	
	/** Sequence constants */
	public static final String COIN_SEQ_KEY = "coinSequence";
	public static final String BOOKIE_SEQ_KEY = "bookieSequence";
	
}
