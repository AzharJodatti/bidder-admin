package com.invictusdynamics.bookie.serviceimpl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.ResourceBundle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.invictusdynamics.bookie.entity.LuckyNumberDetails;
import com.invictusdynamics.bookie.global.SessionValue;
import com.invictusdynamics.bookie.sequence.LuckyNumberSequence;
import com.invictusdynamics.bookie.service.LuckyNumberService;
import com.invictusdynamics.bookie.service.SequenceDao;
import com.invictusdynamics.bookie.utility.Constants;

@Service("luckyNumberServiceImpl")
public class LuckyNumberServiceImpl implements LuckyNumberService {

	/** Resource bundle for exception message */
	ResourceBundle messageBundle = ResourceBundle.getBundle(Constants.MESSAGE_BUNDLE_NAME);

	@Autowired
	private SequenceDao sequenceDao;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private SessionValue sessionValue;

	private static final String LUCKY_NUMBER_SEQ_KEY = "luckyNumberSequence";

	@Override
	public String saveLuckyNumber(Long openValue, Long closeValue, String region) {
		String returnMessage = "", jodiNumber = "";

		if (!region.isEmpty()) {
			LuckyNumberDetails luckyNumberDetails = new LuckyNumberDetails();
			luckyNumberDetails.setId(sequenceDao.getNextSequenceId(LUCKY_NUMBER_SEQ_KEY, LuckyNumberSequence.class));
			luckyNumberDetails.setOpen(openValue);
			luckyNumberDetails.setOpen(closeValue);
			luckyNumberDetails.setRegion(region);
			if (openValue != null && closeValue != null) {
				jodiNumber = String.valueOf(openValue) + String.valueOf(closeValue);
			}
			luckyNumberDetails.setJodi(jodiNumber);
			luckyNumberDetails.setPan(0L);
			luckyNumberDetails.setCreatedBy(sessionValue.getUserId());
			luckyNumberDetails.setCreatedDate(new Timestamp(new Date().getTime()));
			luckyNumberDetails.setUpdatedBy(sessionValue.getUserId());
			luckyNumberDetails.setUpdatedDate(new Timestamp(new Date().getTime()));
			mongoTemplate.save(luckyNumberDetails);
			returnMessage = messageBundle.getString("luckyNumberSaveSuccessMsg");

		} else {

		}
		return returnMessage;
	}

}
