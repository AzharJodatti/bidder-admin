package com.invictusdynamics.bookie.service;

public interface BookieService {
	
	public String saveBookieDetails(String bookieName, long coinTransferValue, long commission) throws Exception;
	
}
